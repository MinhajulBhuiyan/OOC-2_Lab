public class Course
{
    public int courseCode;
    public String courseName;
    public Double courseCredit;
    public type courseType;

    public Course(int courseCode, String courseName, Double courseCredit, type courseType)
    {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.courseCredit = courseCredit;
        this.courseType = courseType;
    }
}
