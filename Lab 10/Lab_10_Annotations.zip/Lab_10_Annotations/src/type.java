public enum type
{
    THEORY,
    LAB
}